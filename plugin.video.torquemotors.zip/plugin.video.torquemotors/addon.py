# -*- coding: utf-8 -*-
"""
Torque Motors Youtube — Kodi 21 (Nexus) Plugin
Plays YouTube playlists, channel videos, and direct watch URLs.
Auto-updates from: https://github.com/MetalDudesMusic/TQYT
"""

import sys
import os
import re
import json
import shutil
import zipfile
import threading
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# ─── Addon bootstrap ─────────────────────────────────────────────────────────
ADDON       = xbmcaddon.Addon()
ADDON_ID    = ADDON.getAddonInfo('id')
ADDON_NAME  = ADDON.getAddonInfo('name')
ADDON_PATH  = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ADDON_DATA  = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
HANDLE      = int(sys.argv[1])
BASE_URL    = sys.argv[0]
ARGS        = urllib.parse.parse_qs(sys.argv[2][1:])

ICON_PATH   = os.path.join(ADDON_PATH, 'resources', 'images', 'icon.png')
FANART_PATH = os.path.join(ADDON_PATH, 'resources', 'images', 'fanart.jpg')
CACHE_FILE  = os.path.join(ADDON_DATA, 'playlist_cache.json')
SOURCES_FILE= os.path.join(ADDON_DATA, 'sources.json')

# ─── GitHub auto-update config ───────────────────────────────────────────────
GITHUB_USER    = 'MetalDudesMusic'
GITHUB_REPO    = 'TQYT'
GITHUB_BRANCH  = 'main'
# Raw base URL for fetching files from the repo
RAW_BASE       = f'https://raw.githubusercontent.com/{GITHUB_USER}/{GITHUB_REPO}/{GITHUB_BRANCH}'
# version.json is stored at the root of the repo
VERSION_URL    = f'{RAW_BASE}/version.json'
# The addon zip is stored as a release asset in the repo
ADDON_ZIP_URL  = f'https://github.com/{GITHUB_USER}/{GITHUB_REPO}/releases/latest/download/plugin.video.torquemotors.zip'
# Fallback: zip stored directly in repo root
ADDON_ZIP_RAW  = f'{RAW_BASE}/plugin.video.torquemotors.zip'

CURRENT_VERSION = '1.0.0'

# Ensure profile data dir exists
if not xbmcvfs.exists(ADDON_DATA):
    xbmcvfs.mkdirs(ADDON_DATA)

# ─── Default sources ─────────────────────────────────────────────────────────
DEFAULT_SOURCES = [
    {
        "name": "Blend Line TV – Playlists",
        "url":  "https://www.youtube.com/@BlendLineTV/playlists",
        "type": "channel_playlists"
    },
    {
        "name": "IMSA Official – Streams",
        "url":  "https://www.youtube.com/@imsaofficial/streams",
        "type": "channel_videos"
    },
    {
        "name": "Goodwood Road & Racing – Videos",
        "url":  "https://www.youtube.com/@GoodwoodRR/videos",
        "type": "channel_videos"
    },
    {
        "name": "Busted Knuckle Video – Playlists",
        "url":  "https://www.youtube.com/@BustedKnuckleVideo/playlists",
        "type": "channel_playlists"
    },
    {
        "name": "Torque Motors Favourite Playlist",
        "url":  "https://www.youtube.com/playlist?list=PLskzXSjH0lBN7XWs3ldiV0M2EMo9lfGY1",
        "type": "playlist"
    }
]

# ─── Logging ─────────────────────────────────────────────────────────────────

def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


# ─── HTTP helpers ─────────────────────────────────────────────────────────────

def http_get(url, headers=None, timeout=15):
    """Simple HTTP GET → text or None."""
    default_headers = {
        'User-Agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/124.0.0.0 Safari/537.36'
        ),
        'Accept-Language': 'en-US,en;q=0.9',
    }
    if headers:
        default_headers.update(headers)
    try:
        req = urllib.request.Request(url, headers=default_headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        log(f'HTTP GET failed [{url[:60]}]: {e}', xbmc.LOGWARNING)
        return None


def http_download(url, dest_path, headers=None, timeout=60):
    """Download binary file to dest_path. Returns True on success."""
    default_headers = {
        'User-Agent': (
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/124.0.0.0 Safari/537.36'
        ),
    }
    if headers:
        default_headers.update(headers)
    try:
        req = urllib.request.Request(url, headers=default_headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            with open(dest_path, 'wb') as f:
                shutil.copyfileobj(resp, f)
        return True
    except Exception as e:
        log(f'Download failed [{url[:60]}]: {e}', xbmc.LOGWARNING)
        return False


# ═══════════════════════════════════════════════════════════════════════════════
# AUTO-UPDATE SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

def version_tuple(v):
    """Convert '1.2.3' → (1, 2, 3) for comparison."""
    try:
        return tuple(int(x) for x in str(v).strip().split('.'))
    except Exception:
        return (0, 0, 0)


def check_for_update(silent=True):
    """
    Fetch version.json from GitHub and compare with CURRENT_VERSION.
    Returns (new_version, zip_url, changelog) or None if no update.
    silent=True → only notify if update found.
    """
    log('Checking for updates...')
    text = http_get(VERSION_URL, timeout=10)
    if not text:
        if not silent:
            xbmcgui.Dialog().notification(
                ADDON_NAME, 'Could not reach GitHub for update check.',
                xbmcgui.NOTIFICATION_WARNING, 4000)
        return None

    try:
        info = json.loads(text)
    except Exception as e:
        log(f'Failed to parse version.json: {e}', xbmc.LOGWARNING)
        return None

    remote_version = str(info.get('version', '0.0.0'))
    changelog      = info.get('changelog', 'Bug fixes and improvements.')
    zip_url        = info.get('zip_url', ADDON_ZIP_RAW)

    if version_tuple(remote_version) > version_tuple(CURRENT_VERSION):
        log(f'Update available: {CURRENT_VERSION} → {remote_version}', xbmc.LOGINFO)
        return remote_version, zip_url, changelog

    log(f'Already up to date ({CURRENT_VERSION})')
    if not silent:
        xbmcgui.Dialog().notification(
            ADDON_NAME, f'Already up to date (v{CURRENT_VERSION})',
            xbmcgui.NOTIFICATION_INFO, 3000)
    return None


def apply_update(new_version, zip_url, changelog):
    """
    Download the new addon zip from GitHub and install it.
    Shows a confirmation dialog first.
    """
    msg = (f'Update available: v{CURRENT_VERSION} → v{new_version}\n\n'
           f'{changelog}\n\nInstall now?')
    if not xbmcgui.Dialog().yesno(ADDON_NAME, msg):
        return False

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f'Downloading update v{new_version}...')
    progress.update(10)

    tmp_zip = os.path.join(ADDON_DATA, 'update.zip')
    tmp_dir = os.path.join(ADDON_DATA, 'update_tmp')

    try:
        # Download zip
        progress.update(20, 'Downloading...')
        ok = http_download(zip_url, tmp_zip)
        if not ok:
            # Try fallback URL
            log('Primary zip URL failed, trying fallback...', xbmc.LOGWARNING)
            ok = http_download(ADDON_ZIP_RAW, tmp_zip)
        if not ok:
            progress.close()
            xbmcgui.Dialog().notification(ADDON_NAME,
                'Download failed. Check internet connection.',
                xbmcgui.NOTIFICATION_ERROR, 5000)
            return False

        progress.update(50, 'Extracting...')

        # Extract to temp dir
        if os.path.isdir(tmp_dir):
            shutil.rmtree(tmp_dir)
        os.makedirs(tmp_dir)

        with zipfile.ZipFile(tmp_zip, 'r') as zf:
            zf.extractall(tmp_dir)

        progress.update(70, 'Installing...')

        # Find the addon folder inside the extracted zip
        extracted_addon = os.path.join(tmp_dir, 'plugin.video.torquemotors')
        if not os.path.isdir(extracted_addon):
            # Maybe it's directly at root
            extracted_addon = tmp_dir

        # Backup current addon (keep resources/images so user art is preserved)
        backup_images = os.path.join(ADDON_DATA, 'backup_images')
        src_images = os.path.join(ADDON_PATH, 'resources', 'images')
        if os.path.isdir(src_images):
            if os.path.isdir(backup_images):
                shutil.rmtree(backup_images)
            shutil.copytree(src_images, backup_images)

        # Copy new files over the existing addon directory
        _copy_update(extracted_addon, ADDON_PATH)

        # Restore user's custom images if they existed
        dest_images = os.path.join(ADDON_PATH, 'resources', 'images')
        if os.path.isdir(backup_images):
            os.makedirs(dest_images, exist_ok=True)
            for fname in os.listdir(backup_images):
                src = os.path.join(backup_images, fname)
                dst = os.path.join(dest_images, fname)
                if os.path.isfile(src) and os.path.getsize(src) > 500:
                    # Only restore if it's a real image (>500 bytes = not placeholder)
                    shutil.copy2(src, dst)
            shutil.rmtree(backup_images)

        progress.update(95, 'Finalising...')

        # Clean up
        for p in [tmp_zip, tmp_dir]:
            try:
                if os.path.isfile(p):
                    os.remove(p)
                elif os.path.isdir(p):
                    shutil.rmtree(p)
            except Exception:
                pass

        progress.update(100, 'Done!')
        progress.close()

        xbmcgui.Dialog().ok(
            ADDON_NAME,
            f'Updated to v{new_version}!\n\n{changelog}\n\n'
            'Kodi will now reload the addon.'
        )

        # Reload the addon
        xbmc.executebuiltin(f'UpdateLocalAddons')
        xbmc.sleep(1000)
        xbmc.executebuiltin('Container.Refresh')
        return True

    except Exception as e:
        progress.close()
        log(f'Update failed: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(ADDON_NAME,
            f'Update failed: {e}',
            xbmcgui.NOTIFICATION_ERROR, 6000)
        return False


def _copy_update(src_dir, dst_dir):
    """Recursively copy src_dir → dst_dir, overwriting existing files."""
    for item in os.listdir(src_dir):
        s = os.path.join(src_dir, item)
        d = os.path.join(dst_dir, item)
        if os.path.isdir(s):
            os.makedirs(d, exist_ok=True)
            _copy_update(s, d)
        else:
            shutil.copy2(s, d)


def check_update_on_startup():
    """Run a silent update check in a background thread at startup."""
    def _check():
        xbmc.sleep(3000)  # wait for Kodi to fully load the plugin
        if ADDON.getSetting('auto_update') != 'true':
            return
        result = check_for_update(silent=True)
        if result:
            new_ver, zip_url, changelog = result
            # Prompt user via main thread using a notification
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                f'Update v{new_ver} available! Open addon to install.',
                xbmcgui.NOTIFICATION_INFO, 8000
            )
    t = threading.Thread(target=_check, daemon=True)
    t.start()


# ═══════════════════════════════════════════════════════════════════════════════
# CACHE & SOURCES
# ═══════════════════════════════════════════════════════════════════════════════

def load_cache():
    if xbmcvfs.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def save_cache(data):
    try:
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
    except Exception as e:
        log(f'Cache save error: {e}', xbmc.LOGWARNING)


def clear_cache():
    save_cache({})
    xbmcgui.Dialog().notification(ADDON_NAME, 'Cache cleared!',
                                   xbmcgui.NOTIFICATION_INFO, 3000)


def load_sources():
    if xbmcvfs.exists(SOURCES_FILE):
        try:
            with open(SOURCES_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            log(f'Sources load error: {e}', xbmc.LOGWARNING)
    save_sources(list(DEFAULT_SOURCES))
    return list(DEFAULT_SOURCES)


def save_sources(sources):
    try:
        with open(SOURCES_FILE, 'w', encoding='utf-8') as f:
            json.dump(sources, f, indent=2, ensure_ascii=False)
    except Exception as e:
        log(f'Sources save error: {e}', xbmc.LOGWARNING)


# ─── URL utilities ────────────────────────────────────────────────────────────

def build_url(**kwargs):
    return BASE_URL + '?' + urllib.parse.urlencode(kwargs)


def extract_playlist_id(url):
    m = re.search(r'[?&]list=([A-Za-z0-9_-]+)', url)
    return m.group(1) if m else None


# ═══════════════════════════════════════════════════════════════════════════════
# YOUTUBE SCRAPING
# ═══════════════════════════════════════════════════════════════════════════════

def extract_initial_data(html):
    """Pull ytInitialData JSON out of a YouTube page."""
    # Try simple pattern first
    for pat in [
        r'var ytInitialData\s*=\s*(\{.+?\});\s*</script>',
        r'ytInitialData\s*=\s*(\{.+?\});\s*(?:var|window|</script>)',
    ]:
        m = re.search(pat, html, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception:
                pass

    # Bracket-match fallback
    idx = html.find('ytInitialData')
    if idx == -1:
        return None
    start = html.find('{', idx)
    if start == -1:
        return None
    depth, i, in_str, escape = 0, start, False, False
    while i < len(html):
        c = html[i]
        if escape:
            escape = False
        elif c == '\\' and in_str:
            escape = True
        elif c == '"':
            in_str = not in_str
        elif not in_str:
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(html[start:i + 1])
                    except Exception:
                        return None
        i += 1
    return None


def walk(obj, key):
    """Recursively collect all values matching key in nested structure."""
    results = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == key:
                results.append(v)
            else:
                results.extend(walk(v, key))
    elif isinstance(obj, list):
        for item in obj:
            results.extend(walk(item, key))
    return results


def get_text(obj):
    if not obj:
        return ''
    if isinstance(obj, str):
        return obj
    if 'simpleText' in obj:
        return obj['simpleText']
    if 'runs' in obj:
        return ''.join(r.get('text', '') for r in obj['runs'])
    return ''


def get_thumbnail(thumbs):
    if not thumbs:
        return ''
    best = sorted(thumbs, key=lambda t: t.get('width', 0), reverse=True)
    url = best[0].get('url', '')
    return url.split('?')[0] if url else ''


def scrape_playlist_videos(playlist_id):
    cache = load_cache()
    key = f'pl_{playlist_id}'
    if key in cache:
        return cache[key]

    html = http_get(f'https://www.youtube.com/playlist?list={playlist_id}')
    if not html:
        return []
    data = extract_initial_data(html)
    if not data:
        return []

    videos = []
    for r in walk(data, 'playlistVideoRenderer'):
        vid_id = r.get('videoId', '')
        if not vid_id:
            continue
        title = get_text(r.get('title', {}))
        thumbs = r.get('thumbnail', {}).get('thumbnails', [])
        thumb = get_thumbnail(thumbs) or f'https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg'
        videos.append({
            'id': vid_id,
            'title': title or vid_id,
            'thumb': thumb,
            'duration': get_text(r.get('lengthText', {})),
            'url': f'https://www.youtube.com/watch?v={vid_id}'
        })

    if videos:
        cache[key] = videos
        save_cache(cache)
    return videos


def scrape_channel_videos(channel_url):
    cache = load_cache()
    key = 'ch_' + re.sub(r'[^a-z0-9]', '_', channel_url.lower())[-60:]
    if key in cache:
        return cache[key]

    html = http_get(channel_url)
    if not html:
        return []
    data = extract_initial_data(html)
    if not data:
        return []

    videos = []
    for r in walk(data, 'richItemRenderer'):
        vr = r.get('content', {}).get('videoRenderer', {})
        if not vr:
            continue
        vid_id = vr.get('videoId', '')
        if not vid_id:
            continue
        title = get_text(vr.get('title', {}))
        thumbs = vr.get('thumbnail', {}).get('thumbnails', [])
        thumb = get_thumbnail(thumbs) or f'https://i.ytimg.com/vi/{vid_id}/hqdefault.jpg'
        videos.append({
            'id': vid_id,
            'title': title or vid_id,
            'thumb': thumb,
            'duration': get_text(vr.get('lengthText', {})),
            'url': f'https://www.youtube.com/watch?v={vid_id}'
        })

    if videos:
        cache[key] = videos
        save_cache(cache)
    return videos


def scrape_channel_playlists(channel_url):
    cache = load_cache()
    key = 'chpl_' + re.sub(r'[^a-z0-9]', '_', channel_url.lower())[-60:]
    if key in cache:
        return cache[key]

    html = http_get(channel_url)
    if not html:
        return []
    data = extract_initial_data(html)
    if not data:
        return []

    playlists = []
    for r in walk(data, 'gridPlaylistRenderer'):
        pl_id = r.get('playlistId', '')
        if not pl_id:
            continue
        title = get_text(r.get('title', {}))
        thumbs = r.get('thumbnail', {}).get('thumbnails', [])
        thumb = get_thumbnail(thumbs)
        playlists.append({
            'id': pl_id,
            'title': title or pl_id,
            'thumb': thumb,
            'count': get_text(r.get('videoCountText', {})),
            'url': f'https://www.youtube.com/playlist?list={pl_id}'
        })

    if playlists:
        cache[key] = playlists
        save_cache(cache)
    return playlists


# ═══════════════════════════════════════════════════════════════════════════════
# STREAM RESOLVER
# ═══════════════════════════════════════════════════════════════════════════════

def resolve_stream_url(video_id):
    """
    Resolve a direct playable stream URL using YouTube's internal APIs.
    No external dependencies. Three strategies tried in order.
    """
    log(f'Resolving stream: {video_id}')

    # ── Strategy 1: innertube Android client ──────────────────────────────────
    try:
        payload = json.dumps({
            "videoId": video_id,
            "context": {
                "client": {
                    "clientName": "ANDROID",
                    "clientVersion": "18.11.34",
                    "androidSdkVersion": 30,
                    "userAgent": "com.google.android.youtube/18.11.34 (Linux; U; Android 11) gzip",
                    "hl": "en",
                    "gl": "US"
                }
            },
            "params": "2AMBCAAQAhgE"
        }).encode('utf-8')

        req = urllib.request.Request(
            'https://www.youtube.com/youtubei/v1/player',
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'User-Agent': 'com.google.android.youtube/18.11.34 (Linux; U; Android 11) gzip',
                'X-YouTube-Client-Name': '3',
                'X-YouTube-Client-Version': '18.11.34',
                'Accept-Language': 'en-US,en;q=0.9',
            }
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        all_fmts = (data.get('streamingData', {}).get('formats', []) +
                    data.get('streamingData', {}).get('adaptiveFormats', []))
        # Prefer muxed (video+audio), otherwise any with a direct URL
        muxed = [f for f in all_fmts
                 if f.get('url') and
                 'video' in f.get('mimeType', '') and
                 'audio' in f.get('mimeType', '')]
        if not muxed:
            muxed = [f for f in all_fmts if f.get('url')]
        if muxed:
            muxed.sort(key=lambda f: f.get('bitrate', 0), reverse=True)
            log('Resolved via innertube Android')
            return muxed[0]['url']
    except Exception as e:
        log(f'Strategy 1 failed: {e}', xbmc.LOGWARNING)

    # ── Strategy 2: innertube WEB client ─────────────────────────────────────
    try:
        payload = json.dumps({
            "videoId": video_id,
            "context": {
                "client": {
                    "clientName": "WEB",
                    "clientVersion": "2.20240101.00.00",
                    "hl": "en",
                    "gl": "US"
                }
            }
        }).encode('utf-8')

        req = urllib.request.Request(
            'https://www.youtube.com/youtubei/v1/player?key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                               'AppleWebKit/537.36 Chrome/124.0 Safari/537.36'),
                'Accept-Language': 'en-US,en;q=0.9',
            }
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))

        fmts = data.get('streamingData', {}).get('formats', [])
        fmts.sort(key=lambda f: f.get('bitrate', 0), reverse=True)
        for f in fmts:
            if f.get('url'):
                log('Resolved via innertube WEB')
                return f['url']
    except Exception as e:
        log(f'Strategy 2 failed: {e}', xbmc.LOGWARNING)

    # ── Strategy 3: Scrape watch page ytInitialPlayerResponse ────────────────
    try:
        html = http_get(f'https://www.youtube.com/watch?v={video_id}')
        if html:
            m = re.search(
                r'ytInitialPlayerResponse\s*=\s*(\{.+?\});\s*(?:var|</script>)',
                html, re.DOTALL)
            if m:
                player = json.loads(m.group(1))
                fmts = player.get('streamingData', {}).get('formats', [])
                fmts.sort(key=lambda f: f.get('bitrate', 0), reverse=True)
                for f in fmts:
                    if f.get('url'):
                        log('Resolved via watch page scrape')
                        return f['url']
    except Exception as e:
        log(f'Strategy 3 failed: {e}', xbmc.LOGWARNING)

    log(f'All strategies failed for {video_id}', xbmc.LOGERROR)
    return None


# ═══════════════════════════════════════════════════════════════════════════════
# KODI UI HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def set_fanart():
    xbmcplugin.setPluginFanart(HANDLE, FANART_PATH)


def make_listitem(title, thumb='', fanart='', is_folder=False, duration=0):
    li = xbmcgui.ListItem(label=title)
    li.setArt({
        'thumb':  thumb  or ICON_PATH,
        'icon':   thumb  or ICON_PATH,
        'fanart': fanart or FANART_PATH,
        'poster': thumb  or ICON_PATH,
    })
    if not is_folder:
        li.setProperty('IsPlayable', 'true')
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            if duration:
                tag.setDuration(duration)
        except Exception:
            info = {'title': title}
            if duration:
                info['duration'] = duration
            li.setInfo('video', info)
    return li


def parse_duration(text):
    try:
        parts = list(map(int, text.strip().split(':')))
        if len(parts) == 3:
            return parts[0] * 3600 + parts[1] * 60 + parts[2]
        if len(parts) == 2:
            return parts[0] * 60 + parts[1]
    except Exception:
        pass
    return 0


# ═══════════════════════════════════════════════════════════════════════════════
# MENU & DIRECTORY BUILDERS
# ═══════════════════════════════════════════════════════════════════════════════

def show_main_menu():
    set_fanart()
    xbmcplugin.setContent(HANDLE, 'videos')

    sources = load_sources()

    # ── Check for pending update notification ────────────────────────────────
    update_flag = os.path.join(ADDON_DATA, 'update_available.json')
    pending_update = None
    if os.path.isfile(update_flag):
        try:
            with open(update_flag) as f:
                pending_update = json.load(f)
        except Exception:
            pass

    if pending_update:
        label = (f'[COLOR orange]🔔  Update v{pending_update["version"]} Available — '
                 f'Tap to install[/COLOR]')
        li = make_listitem(label, thumb=ICON_PATH, is_folder=True)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            build_url(action='install_update',
                      version=pending_update['version'],
                      zip_url=pending_update['zip_url'],
                      changelog=pending_update.get('changelog', '')),
            li, isFolder=True)

    # ── Source entries ────────────────────────────────────────────────────────
    for i, src in enumerate(sources):
        li = make_listitem(src['name'], thumb=ICON_PATH, is_folder=True)
        li.addContextMenuItems([
            ('Remove this source',
             f'RunPlugin({build_url(action="remove_source", index=str(i))})'),
        ])
        xbmcplugin.addDirectoryItem(
            HANDLE, build_url(action='open_source', index=str(i)),
            li, isFolder=True)

    # ── Action items ──────────────────────────────────────────────────────────
    items = [
        ('[COLOR green]➕  Add YouTube URL[/COLOR]',  'add_source'),
        ('[COLOR yellow]⚙  Settings[/COLOR]',         'open_settings'),
        ('[COLOR cyan]🔄  Check for Updates[/COLOR]', 'check_update'),
        ('[COLOR red]🗑  Clear Cache[/COLOR]',        'clear_cache'),
    ]
    for label, action in items:
        li = make_listitem(label, thumb=ICON_PATH, is_folder=True)
        xbmcplugin.addDirectoryItem(HANDLE, build_url(action=action), li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def show_source(index):
    sources = load_sources()
    try:
        src = sources[int(index)]
    except (IndexError, ValueError):
        xbmcgui.Dialog().notification(ADDON_NAME, 'Source not found',
                                       xbmcgui.NOTIFICATION_ERROR)
        return

    xbmcplugin.setContent(HANDLE, 'videos')
    set_fanart()

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f'Loading: {src["name"]}')
    progress.update(10)

    try:
        src_type = src.get('type', 'playlist')
        src_url  = src['url']

        if src_type == 'playlist':
            pl_id = extract_playlist_id(src_url)
            if pl_id:
                progress.update(30)
                videos = scrape_playlist_videos(pl_id)
                progress.update(80)
                show_video_list(videos)
            else:
                xbmcgui.Dialog().notification(ADDON_NAME, 'Invalid playlist URL',
                                               xbmcgui.NOTIFICATION_ERROR)

        elif src_type == 'channel_videos':
            progress.update(30)
            videos = scrape_channel_videos(src_url)
            progress.update(80)
            show_video_list(videos)

        elif src_type == 'channel_playlists':
            progress.update(30)
            playlists = scrape_channel_playlists(src_url)
            progress.update(80)
            show_playlist_list(playlists)

        else:
            xbmcgui.Dialog().notification(ADDON_NAME, 'Unknown source type',
                                           xbmcgui.NOTIFICATION_ERROR)
    finally:
        progress.close()


def show_playlist_list(playlists):
    if not playlists:
        xbmcgui.Dialog().notification(ADDON_NAME, 'No playlists found',
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for pl in playlists:
        label = pl['title']
        if pl.get('count'):
            label += f'  ({pl["count"]})'
        li = make_listitem(label, thumb=pl.get('thumb', ''), is_folder=True)
        xbmcplugin.addDirectoryItem(
            HANDLE, build_url(action='open_playlist', playlist_id=pl['id']),
            li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_video_list(videos):
    if not videos:
        xbmcgui.Dialog().notification(ADDON_NAME, 'No videos found',
                                       xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    pl_json = urllib.parse.quote(json.dumps([v['id'] for v in videos]))

    for idx, v in enumerate(videos):
        li = make_listitem(v['title'], thumb=v.get('thumb', ''),
                           duration=parse_duration(v.get('duration', '')))
        url = build_url(action='play_video', video_id=v['id'],
                        playlist=pl_json, pl_index=str(idx))
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, updateListing=False, cacheToDisc=False)


def open_playlist(playlist_id):
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, 'Loading playlist...')
    progress.update(20)
    videos = scrape_playlist_videos(playlist_id)
    progress.update(90)
    progress.close()
    xbmcplugin.setContent(HANDLE, 'videos')
    set_fanart()
    show_video_list(videos)


# ═══════════════════════════════════════════════════════════════════════════════
# PLAYBACK
# ═══════════════════════════════════════════════════════════════════════════════

def play_video(video_id, playlist_ids=None, pl_index=0):
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, 'Resolving stream...')
    progress.update(20)
    stream_url = resolve_stream_url(video_id)
    progress.update(90)
    progress.close()

    if not stream_url:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            'Stream could not be resolved. Try clearing cache or check for an update.',
            xbmcgui.NOTIFICATION_ERROR, 6000)
        return

    li = xbmcgui.ListItem(path=stream_url)
    li.setArt({'thumb': f'https://i.ytimg.com/vi/{video_id}/hqdefault.jpg',
               'fanart': FANART_PATH})
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(video_id)
    except Exception:
        li.setInfo('video', {'title': video_id})
    li.setProperty('IsPlayable', 'true')
    li.setMimeType('video/mp4')
    li.setContentLookup(False)

    xbmcplugin.setResolvedUrl(HANDLE, True, li)

    # Autoplay next
    if playlist_ids and ADDON.getSetting('autoplay') == 'true':
        try:
            next_idx = int(pl_index) + 1
            if next_idx < len(playlist_ids):
                _queue_next_video(playlist_ids[next_idx], playlist_ids, next_idx)
        except Exception as e:
            log(f'Autoplay error: {e}', xbmc.LOGWARNING)


def _queue_next_video(next_id, playlist_ids, next_index):
    """Background thread: wait for current video to finish, then play next."""
    def _watch():
        player  = xbmc.Player()
        monitor = xbmc.Monitor()
        # Wait for playback to start (up to 10s)
        for _ in range(20):
            xbmc.sleep(500)
            if player.isPlaying():
                break
        else:
            return
        # Wait for it to end
        while player.isPlaying():
            xbmc.sleep(1000)
            if monitor.abortRequested():
                return
        xbmc.sleep(1500)
        if not player.isPlaying():
            log(f'Autoplay → {next_id}')
            next_url = build_url(
                action='play_video',
                video_id=next_id,
                playlist=urllib.parse.quote(json.dumps(playlist_ids)),
                pl_index=str(next_index)
            )
            xbmc.executebuiltin(f'RunPlugin({next_url})')

    threading.Thread(target=_watch, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
# SOURCE MANAGEMENT
# ═══════════════════════════════════════════════════════════════════════════════

def add_source():
    kb = xbmcgui.Dialog()
    url_raw = kb.input('Enter YouTube URL', type=xbmcgui.INPUT_ALPHANUM)
    if not url_raw:
        return
    url_raw = url_raw.strip()

    if '/playlists' in url_raw:
        src_type = 'channel_playlists'
    elif '/videos' in url_raw or '/streams' in url_raw:
        src_type = 'channel_videos'
    elif 'list=' in url_raw:
        src_type = 'playlist'
    else:
        choice = kb.select('What type of URL is this?',
                           ['Playlist', 'Channel Videos/Streams', 'Channel Playlists'])
        src_type = ['playlist', 'channel_videos', 'channel_playlists'][choice] \
                   if choice >= 0 else 'playlist'

    name = kb.input('Give this source a name', type=xbmcgui.INPUT_ALPHANUM)
    if not name:
        name = url_raw[:50]

    sources = load_sources()
    sources.append({'name': name, 'url': url_raw, 'type': src_type})
    save_sources(sources)
    xbmcgui.Dialog().notification(ADDON_NAME, f'"{name}" added!',
                                   xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin('Container.Refresh')


def remove_source(index):
    sources = load_sources()
    try:
        removed = sources.pop(int(index))
        save_sources(sources)
        xbmcgui.Dialog().notification(ADDON_NAME, f'Removed: {removed["name"]}',
                                       xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')
    except (IndexError, ValueError) as e:
        log(f'Remove source error: {e}', xbmc.LOGWARNING)


# ═══════════════════════════════════════════════════════════════════════════════
# ROUTER
# ═══════════════════════════════════════════════════════════════════════════════

def router():
    action = ARGS.get('action', [None])[0]

    if action is None:
        check_update_on_startup()
        show_main_menu()

    elif action == 'open_source':
        show_source(ARGS.get('index', ['0'])[0])

    elif action == 'open_playlist':
        open_playlist(ARGS.get('playlist_id', [''])[0])

    elif action == 'play_video':
        video_id = ARGS.get('video_id', [''])[0]
        pl_raw   = ARGS.get('playlist', ['[]'])[0]
        pl_index = ARGS.get('pl_index', ['0'])[0]
        try:
            playlist_ids = json.loads(urllib.parse.unquote(pl_raw))
        except Exception:
            playlist_ids = []
        play_video(video_id, playlist_ids, int(pl_index))

    elif action == 'add_source':
        add_source()

    elif action == 'remove_source':
        remove_source(ARGS.get('index', ['0'])[0])

    elif action == 'clear_cache':
        clear_cache()
        xbmc.executebuiltin('Container.Refresh')

    elif action == 'open_settings':
        ADDON.openSettings()

    elif action == 'check_update':
        result = check_for_update(silent=False)
        if result:
            new_ver, zip_url, changelog = result
            # Save flag so main menu shows the update banner
            flag = os.path.join(ADDON_DATA, 'update_available.json')
            with open(flag, 'w') as f:
                json.dump({'version': new_ver, 'zip_url': zip_url,
                           'changelog': changelog}, f)
            apply_update(new_ver, zip_url, changelog)
        xbmc.executebuiltin('Container.Refresh')

    elif action == 'install_update':
        new_ver   = ARGS.get('version', [''])[0]
        zip_url   = urllib.parse.unquote(ARGS.get('zip_url', [ADDON_ZIP_RAW])[0])
        changelog = urllib.parse.unquote(ARGS.get('changelog', [''])[0])
        if new_ver:
            if apply_update(new_ver, zip_url, changelog):
                # Clear the flag after successful update
                flag = os.path.join(ADDON_DATA, 'update_available.json')
                try:
                    os.remove(flag)
                except Exception:
                    pass
        xbmc.executebuiltin('Container.Refresh')

    else:
        log(f'Unknown action: {action}', xbmc.LOGWARNING)
        show_main_menu()


if __name__ == '__main__':
    router()
